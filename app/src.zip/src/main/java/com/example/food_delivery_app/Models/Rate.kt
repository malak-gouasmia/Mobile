package com.example.food_delivery_app.Models

data class Rate(val userId: String,
                val rating: Int,
                val message: String)
