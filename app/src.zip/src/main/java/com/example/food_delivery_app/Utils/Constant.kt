package com.example.food_delivery_app.Utils



class Constant {
    final val url="https://6c4e-129-45-26-137.ngrok-free.app"

}