package com.example.food_delivery_app.Models


data class Location(
    val title: String,
    val latitude: Double,
    val longitude: Double
)
